<!DOCTYPE HTML>
<html lang = "en">
  <head>
    <title>Doctors page</title>
    <meta charset = "UTF-8" />
  </head>
  <style>
    body{
      background-image: url(https://www.iamexpat.de/sites/default/files/styles/article--full/public/general-practitioners-gps-germany.jpg?itok=j8OikpEM);
      background-size:cover;
       }
   form{
    padding-left: 350px;
    padding-right: 300px;
    a

    }

   textarea{
    padding-right:180px;
    padding-bottom: 60px;
  
   }
   div{
    
   }
   input{
    padding-right:60px;
    padding-bottom: 10px;
   }
  </style>
  <body>
     @extends('layouts.app')

@section('content')
    
    <form>
      <div>
       <h1>Doctor's Diagnosis Form</h1>
       
        <p>
          <td> Pets' Name </td></br>
          <td><input type ="text" name="name"></td>
          <td><input type ="text" name="name"></td>
          </p>
          <p>
          <td>breed</td></br>
          <td><input type ="text" name="name"></td>
          <td><input type ="text" name="name"></td>
          </p>
           <p>
          <td> sex</td></br>
          <td><input type ="text" name="name"></td>
          <td><input type ="text" name="name"></td>
          </p>
          <p>
          <td>  age</td></br>
          <td><input type ="text" name="name"></td>
          <td><input type ="text" name="name"></td>
          </p>
         
      
    
        <p>
         <label>Pets history</label></br>
          <textarea> </textarea></br>
          <label>signs and symptoms</label></br>
          <textarea> </textarea></br>
          <label>possible illness</label></br>
          <textarea></textarea>
          <td>
          <input type="submit" name="Add" value="Add +"></td>
        </p>
      </div>
    </form>
    @endsection
  </body>
</html>