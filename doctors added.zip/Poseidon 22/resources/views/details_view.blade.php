<html>
   
   <head>
      <title>Owner/pet details</title>
       <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <style >
    html, body {
                background-color: #fff;
                font-weight: 100;
                height: 100vh;
                margin: 0;
                background-image:url(https://wallpapercave.com/wp/wp3123748.jpg);
                background-size: cover;
            }
    
</style>
   </head>
   
   <body>
    @extends('layouts.app')

@section('content')
    <h1><center>Dog and Owner details</center></h1>
      <div class="w3-container">
      <table class="w3-table-all w3-hoverable">
        <thead>
         <tr class="w3-light-grey">
           <td>First name</td>
           <td>Last name</td>
           <td>Area Code</td>
           <td>Phone Number</td>
           <td>Pet Name</td>
           <td>Pet Type</td>
           <td>Pet Color</td>
           <td>Reference Number</td>
         </tr>
         </thead>
         @foreach ($details as $details)
         <tr>
            <td>{{ $details->firstname }}</td>
            <td>{{ $details->lastname }}</td>
            <td>{{ $details->areacode }}</td>
            <td>{{ $details->phone }}</td>
            <td>{{ $details->petname }}</td>
            <td>{{ $details->pettype }}</td>
            <td>{{ $details->petcolor }}</td>
            <td>{{ $details->refno }}</td>
         </tr>
         @endforeach
      </table>
      </div>
       @endsection
   </body>
</html>