<!DOCTYPE html>
<body>
<center>
<form action="/insert" method="post">
	<table>
		<tr>
			<?php echo e(csrf_field()); ?>

			<td>Name :</td>
			<td><input type ="text" name="name"></td>
		</tr>
		<tr>
			<td>Description : </td>
			<td><input type ="text" name="description"></td>
		</tr>
		<tr>
			<td>Quantity : </td>
			<td><input type ="text" name="quantity"></td>
		</tr>
		<tr>
			<td>Date : </td>
			<td><input type ="date" name="date"></td>
		</tr>
		<tr>
			<td><input type="submit" name="submit" value="Add"></td>
		</tr>
	</table>
</form>
</center>

<center>
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<table>
			<tr>
				<td>Name</td>
				<td>Description</td>
				<td>Quantity</td>
				<td>Date</td>
				<td>Action</td>
			</tr>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($value->name); ?></td>
				<td><?php echo e($value->description); ?></td>
				<td><?php echo e($value->quantity); ?></td>
				<td><?php echo e($value->date); ?></td>
				<td><a href=""><button>Edit</button></a>$nbsp;<a href=""><button>Delete</button></a></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	
</center>
</body>
</html>