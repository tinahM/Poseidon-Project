<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class InventoryController extends Controller
{
    public function index()
    {
    	 $items = DB::table('inventory')->get();
      return view('inventory_view',['items'=>$items]);
    }

    public function owner()
    {
    	$details = DB::table('details')->get();
    	return view('details_view',['details'=>$details]);
    }
}
