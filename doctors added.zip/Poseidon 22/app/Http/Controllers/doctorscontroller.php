<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class doctorscontroller extends Controller
{
    public function index()
    {
    	 $items = DB::table('doctors')->get();
      return view('doctorsview',['items'=>$items]);
    }

    public function view()
    {
        return view('diagnosis');
    }

    
}
