<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class InventoryController extends Controller
{
    public function index()
    {
    	 $items = DB::table('inventory')->get();
      return view('inventory_view',['items'=>$items]);
    }

    public function owner()
    {
    	$details = DB::table('details')->get();
    	return view('details_view',['details'=>$details]);
    }

    public function insertdata(Request $request){

        $firstname = $request->input('firstname');
        $lastname = $request->input('lastname');
        $areacode = $request->input('areacode');
        $phone = $request->input('phone');
        $petname = $request->input('petname');
        $pettype = $request->input('pettype');
        $petcolor = $request->input('petcolor');
        $refno = $request->input('refno');

        $data = array('firstname'=>$firstname,'lastname'=>$lastname,"areacode"=>$areacode,"phone"=>$phone,"petname"=>$petname,'pettype'=>$pettype,'petcolor'=>$petcolor,'refno'=>$refno);
        DB::table('details')->insert($data);
        return $this->owner();

}

    public function insert(Request $request){

        $name = $request->input('name');
        $description = $request->input('description');
        $quantity = $request->input('quantity');
        $date = $request->input('date');

        $data = array('name'=>$name,"description"=>$description,"quantity"=>$quantity,"date"=>$date);
        DB::table('inventory')->insert($data);
        
        return $this->index();
}
}
