<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class doctorscontroller extends Controller
{
    public function index()
    {
    	 $items = DB::table('doctors')->get();
      return view('doctorsview',['items'=>$items]);
    }

    public function view()
    {
        return view('diagnosis');
    }
}
