<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class PetController extends Controller
{
    public function insert(Request $request){

        $pname = $request->input('pname');
        $breed = $request->input('breed');
        $sex = $request->input('sex');
        $age = $request->input('age');
        $history = $request->input('history');
        $signs = $request->input('signs');
        $illness = $request->input('illness');

        $data = array('pname'=>$pname,"breed"=>$breed,"sex"=>$sex,"age"=>$age,'history'=>$history,'signs'=>$signs,'illness'=>$illness);
        DB::table('pet')->insert($data);
echo "Record inserted successfully.<br/>";

}
}
