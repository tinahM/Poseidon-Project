<html>
   
   <head>
      <title>Owner/pet details</title>
       <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <style >
    html, body {
                color: "black";
                background-color: #fff;
                font-weight: 100;
                height: 100vh;
                margin: 0;
                background-image:url(https://wallpapercave.com/wp/wp3123748.jpg);
                background-size: cover;
            }
    
</style>
   </head>
   
   <body>
    

<?php $__env->startSection('content'); ?>

<form action = "/new" method = "post">
<table style="color: black;">
<tr>
  <?php echo e(csrf_field()); ?>

<td>First Name: </td><br>
<td><input type='text' name='firstname' /></td>
</tr>

<td>Last Name: </td>
<td><br><input type='text' name='lastname' /></td>
</tr>
<tr>
<td>Area Code: </td>
<td><br><input type="text" name='areacode'/></td>
</tr>
<tr>
  <td>Phone Number: </td>
<td><br><input type='text' name='phone' /></td>
</tr>
<td>Pet Name: </td>
<td><br><input type="text" name='petname'/></td>
</tr>
<td>Pet Type: </td>
<td><br><input type='text' name='pettype' /></td>
</tr>
<tr>
<td>Pet Color </td>
<td><br><input type="text" name='petcolor'/></td>
</tr>
<td>Reference Number: </td>
<td><br><input type='text' name='refno' /></td>
</tr>
<tr>
<td colspan = '2'>
<input style="color: black;" type = 'submit' value = "Submit"/>
</td>
</tr>
</table>
</form>
    <h1><center>Dog and Owner details</center></h1>
      <div class="w3-container">
      <table class="w3-table-all w3-hoverable">
        <thead>
         <tr class="w3-light-grey">
           <td>First name</td>
           <td>Last name</td>
           <td>Area Code</td>
           <td>Phone Number</td>
           <td>Pet Name</td>
           <td>Pet Type</td>
           <td>Pet Color</td>
           <td>Reference Number</td>
         </tr>
         </thead>
         <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($details->firstname); ?></td>
            <td><?php echo e($details->lastname); ?></td>
            <td><?php echo e($details->areacode); ?></td>
            <td><?php echo e($details->phone); ?></td>
            <td><?php echo e($details->petname); ?></td>
            <td><?php echo e($details->pettype); ?></td>
            <td><?php echo e($details->petcolor); ?></td>
            <td><?php echo e($details->refno); ?></td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
      </div>
       <?php $__env->stopSection(); ?>
   </body>
</html>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>