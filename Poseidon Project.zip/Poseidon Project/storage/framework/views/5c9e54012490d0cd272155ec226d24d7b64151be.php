<html>
   
   <head>
      <title>Inventory View</title>

      <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
   <style >
    html, body {
                background-color: #fff;
                font-weight: 100;
                height: 100vh;
                margin: 0;
                background-image:url(https://wallpapercave.com/wp/wp3123723.jpg);
                background-size: cover;
            }
    
</style>
   </head>
   
   <body>
      

<?php $__env->startSection('content'); ?>
  <h1><center>Inventory</center></h1>
  <h2>Add to stock</h2>
  <form action = "/insert" method = "post">
<table>
<tr>
  <?php echo e(csrf_field()); ?>

<td>Name of Item: </td>
<td><input type='text' name='name' /></td>
</tr>
<tr>
<td>Description: </td>
<td><input type="text" name='description'/></td>
</tr>
<tr>
<td>Quantity: </td>
<td><input type="text" name='quantity'/></td>
</tr>
<tr>
<td>Date: </td>
<td><input type="date" name='date'/></td>
</tr>
<tr>
<td colspan = '2'>
<input type = 'submit' value = "Submit"/>
</td>
</tr>
</table>
</form>
      <h2>Stock Inventory</h2>
      <div class="w3-container">
      <table class="w3-table-all w3-hoverable">
         <thead>
         <tr class="w3-light-grey">
           <td>Name</td>
           <td>Description</td>
           <td>Quantity</td>
           <td>Date</td>
         </tr>
         </thead>
         <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($items->name); ?></td>
            <td><?php echo e($items->description); ?></td>
            <td><?php echo e($items->quantity); ?></td>
            <td><?php echo e($items->date); ?></td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
   </div>
   <?php $__env->stopSection(); ?>
   </body>
</html>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>