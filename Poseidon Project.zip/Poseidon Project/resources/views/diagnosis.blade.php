<!DOCTYPE HTML>
<html lang = "en">
  <head>
    <title>Doctors page</title>
    <meta charset = "UTF-8" />
  </head>
  <style>
    body{
      background-image: url(https://www.iamexpat.de/sites/default/files/styles/article--full/public/general-practitioners-gps-germany.jpg?itok=j8OikpEM);
      background-size:cover;


       }
   form{
    padding-left: 350px;
    padding-right: 300px;
    a

    }

   textarea{
    padding-right:180px;
    padding-bottom: 60px;
  
   }
   div{
    
   }
   input{
    padding-right:60px;
    padding-bottom: 10px;
   }
  </style>
  <body>
     @extends('layouts.app')

@section('content')
    
    <form action = "/create" method="post"><center>
      <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
<h1>Doctor's Diagnosis Page</h1>
<table>
<tr>
<td>Pets' Name: </td>
<td><br><input type='text' name='pname' /></td><br>
<tr><br>
<br><td>breed:</td>
<td><br><input type="text" name='breed'/></td><br>
</tr>
<tr>
<br><td>Sex:</td>
<td>
<br><select name="sex">
<option value="female">Female</option>
<option value="male">Male</option><br>
</select></td>
</tr>
<tr>
<td>Age:</td>
<td><br><input type="text" name='age'/></td><br>
</tr>

</tr>
<tr>
<td>Pet's History:</td>
<td><br><textarea input type="text" name="history" placeholder="Enter Pet History..."> </textarea></br>
</td>
</tr>

<tr>
<td>Signs and Symptoms:</td>
<td><br><textarea input type="text" name="signs" placeholder="Enter Pet Symptoms..."> </textarea><br>
</td>
</tr>

<tr>
<td>Possible illness:</td>
<td><br><textarea input type="text" name="illness" placeholder="Enter suspected illness..."> </textarea><br>
</td>
</tr>

<tr>
<td colspan = '2'>
<br><center><input type = 'submit' value = "Submit"/></center>
</td>
</tr>
</table>
 </center>
</form>
 @endsection
</body>
</html>
      
    