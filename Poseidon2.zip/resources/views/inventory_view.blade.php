<html>
   
   <head>
      <title>Inventory View</title>

      <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
   <style >
    html, body {
                background-color: #fff;
                font-weight: 100;
                height: 100vh;
                margin: 0;
                background-image:url(https://wallpapercave.com/wp/wp3123723.jpg);
                background-size: cover;
            }
    
</style>
   </head>
   
   <body>
      @extends('layouts.app')

@section('content')
      <h1><center>Inventory</center></h1>
      <div class="w3-container">
      <table class="w3-table-all w3-hoverable">
         <thead>
         <tr class="w3-light-grey">
           <td>Name</td>
           <td>Description</td>
           <td>Quantity</td>
           <td>Date</td>
         </tr>
         </thead>
         @foreach ($items as $items)
         <tr>
            <td>{{ $items->name }}</td>
            <td>{{ $items->description }}</td>
            <td>{{ $items->quantity }}</td>
            <td>{{ $items->date }}</td>
         </tr>
         @endforeach
      </table>
   </div>
   @endsection
   </body>
</html>