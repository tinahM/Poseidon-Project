<!DOCTYPE html>
<body>
<center>
<form action="/insert" method="post">
	<table>
		<tr>
			{{ csrf_field() }}
			<td>Name :</td>
			<td><input type ="text" name="name"></td>
		</tr>
		<tr>
			<td>Description : </td>
			<td><input type ="text" name="description"></td>
		</tr>
		<tr>
			<td>Quantity : </td>
			<td><input type ="text" name="quantity"></td>
		</tr>
		<tr>
			<td>Date : </td>
			<td><input type ="date" name="date"></td>
		</tr>
		<tr>
			<td><input type="submit" name="submit" value="Add"></td>
		</tr>
	</table>
</form>
</center>

<center>
	@foreach($data as $value)
		<table>
			<tr>
				<td>Name</td>
				<td>Description</td>
				<td>Quantity</td>
				<td>Date</td>
				<td>Action</td>
			</tr>
			@foreach($data as $value)
			<tr>
				<td>{{ $value->name }}</td>
				<td>{{ $value->description }}</td>
				<td>{{ $value->quantity }}</td>
				<td>{{ $value->date }}</td>
				<td><a href=""><button>Edit</button></a>$nbsp;<a href=""><button>Delete</button></a></td>
			</tr>
			@endforeach
		</table>
	
</center>
</body>
</html>